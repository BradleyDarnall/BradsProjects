﻿using Microsoft.VisualBasic;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;

namespace Bradsproject1._19._23
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // call the run method, it will return nothing 
            //Run();
            Run2();




        }

        public static void Run()
        {   // char is short for character, is a single character, usins single quotes '
            char alpha = 'a';
            // string is multiple characters strung together, uses "
            string sentence = "this is a sentence";
            string word = "this is a word";
            string Word = "THIS IS A WORD";
            string WORD = "THESE ARE WORDS";
            Console.WriteLine(word + " " + Word + " " + WORD);
            Console.WriteLine();
            Console.WriteLine();

            // int is short for int32 which is an integer 
            int number1 = 10;

            // decimal is for decimal numbers 
            decimal floatingNumber = 12.34m;

            // datetime is for date times
            DateTime today = DateTime.Now;
            Console.WriteLine("give me a name");
            string name = Console.ReadLine();

            Console.WriteLine();
            Console.WriteLine("give me a number");
            string number = Console.ReadLine();

            Console.WriteLine();
            Console.WriteLine("give me an adjective");
            string adjective = Console.ReadLine();

            Console.WriteLine();
            Console.WriteLine(name + " is " + number + " years old and is " + adjective);

            Console.WriteLine("----------------------------------------------------------");
            Console.WriteLine();

            Console.WriteLine("What is number 1");
            string input1 = Console.ReadLine();

            Console.WriteLine("What is number 2?");
            string input2 = Console.ReadLine();


            Console.WriteLine(input1 + input2);
            Console.WriteLine();

            int conversion1 = Convert.ToInt32(input1);
            int conversion2 = Convert.ToInt32(input2);
            int result = conversion1 + conversion2;

            //this is bad; concatenates strings 
            Console.WriteLine(input1 + " + " + input2 + " = " + conversion1 + conversion2);

            // this one is good; paranthesis give it order of operations
            Console.WriteLine(input1 + " + " + input2 + " = " + (conversion1 + conversion2));

            // this is good because it is already a result
            Console.WriteLine(input1 + " + " + input2 + " = " + result);


            Console.WriteLine("--------------------------------------------------------");
            Console.WriteLine();

            bool repeat = true;
            while (repeat == true)
            {








                Console.WriteLine("Is David Cool y/n?");
                string yesNo = Console.ReadLine();

                // if statement is TRUE go inside the brackets; if false do not that 
                if (yesNo == "y")
                {
                    Console.WriteLine("Are you sure?");
                    string yesNo2 = Console.ReadLine();
                    if (yesNo2 == "y")
                    {
                        Console.WriteLine("Are you really sure?");
                        string yesno3 = Console.ReadLine();
                        if (yesno3 == "y")
                        {
                            Console.WriteLine("Ok i guess he is cool");


                        }
                        else if (yesno3 == "n")
                        {
                            Console.WriteLine("I'm glad you came to your senses!");

                        }
                    }
                    else if (yesNo2 == "n")
                    {
                        Console.WriteLine("That is correct");
                    }
                }
                else if (yesNo == "n")
                {
                    Console.WriteLine(" That is correct");
                }
                else
                {
                    Console.WriteLine("Thats not a y or n");
                }

                Console.WriteLine("Press y to repeat");
                string doRepeat = Console.ReadLine();
                if (doRepeat == "y")
                {
                    repeat = true;

                }
                else
                {
                    repeat = false;
                }

            }

        }

        public static void Run2()
            // lab number 1 from bootcamp book 
        {
            string repeat = "";

            do
            {
                Console.WriteLine("What is the Length");
                string input1 = Console.ReadLine();

                Console.WriteLine("What is the width?");
                string input2 = Console.ReadLine();

                decimal conversion1 = Convert.ToDecimal(input1);
                decimal conversion2 = Convert.ToDecimal(input2);
                decimal area = conversion1 * conversion2;
                decimal perimeter = (2 * conversion1) + (2 * conversion2);
                Console.WriteLine("area equals: " + area.ToString() + " and the perimeter equals:" + perimeter);

                Console.WriteLine("Press y to repeat");
                   repeat =  Console.ReadLine();

            } while (repeat == "y");

            if (repeat == "n")
            {
                Console.WriteLine("go eat a bag of dicks!");

            }

            int x = 0;
            while (repeat == "n")
            {
                Console.WriteLine("go eat a bag of dicks!");
                x = x+1;
                if (x == 10)
                {
                    break;
                }
            }





        }
    }
}